﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IGatePatni.WinForms.WinApplicationLab3Q1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Click(object sender, EventArgs e)
        {

        }

        private void btnwelcome_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome " + txtname.Text + " !!!");
        }

        private void btnwelcome_MouseEnter(object sender, EventArgs e)
        {
            //sender is source of event ie: btnwelcome button.
            Button b = sender as Button;
            b.BackColor = Color.Yellow;
            b.ForeColor = Color.OrangeRed;
        }

        private void btnwelcome_MouseLeave(object sender, EventArgs e)
        {
            //sender is source of event ie: btnwelcome button.
            Button b = sender as Button;
            b.BackColor = SystemColors.Control;
            b.ForeColor = Color.Black;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnclose.Click += new EventHandler(btnclose_Click);
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void btnclose_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtname_MouseEnter(object sender, EventArgs e)
        {
            txtname.BackColor = Color.Yellow;
        }
    }
}
