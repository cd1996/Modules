﻿namespace IGatePatni.WinForms.WinApplicationLab3Q1
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistrationForm));
            this.lblName = new System.Windows.Forms.Label();
            this.lblBirthDate = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtbirthdate = new System.Windows.Forms.TextBox();
            this.imgcal = new System.Windows.Forms.PictureBox();
            this.btnregistration = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.imgcal)).BeginInit();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(104, 75);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name";
            // 
            // lblBirthDate
            // 
            this.lblBirthDate.AutoSize = true;
            this.lblBirthDate.Location = new System.Drawing.Point(88, 144);
            this.lblBirthDate.Name = "lblBirthDate";
            this.lblBirthDate.Size = new System.Drawing.Size(51, 13);
            this.lblBirthDate.TabIndex = 1;
            this.lblBirthDate.Text = "BirthDate";
            this.lblBirthDate.Click += new System.EventHandler(this.lblBirthDate_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(196, 72);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(216, 20);
            this.txtName.TabIndex = 2;
            // 
            // txtbirthdate
            // 
            this.txtbirthdate.Location = new System.Drawing.Point(196, 144);
            this.txtbirthdate.Name = "txtbirthdate";
            this.txtbirthdate.Size = new System.Drawing.Size(216, 20);
            this.txtbirthdate.TabIndex = 3;
            // 
            // imgcal
            // 
            this.imgcal.Image = ((System.Drawing.Image)(resources.GetObject("imgcal.Image")));
            this.imgcal.Location = new System.Drawing.Point(445, 144);
            this.imgcal.Name = "imgcal";
            this.imgcal.Size = new System.Drawing.Size(29, 20);
            this.imgcal.TabIndex = 4;
            this.imgcal.TabStop = false;
            this.imgcal.Click += new System.EventHandler(this.imgcal_Click);
            // 
            // btnregistration
            // 
            this.btnregistration.Location = new System.Drawing.Point(267, 260);
            this.btnregistration.Name = "btnregistration";
            this.btnregistration.Size = new System.Drawing.Size(103, 37);
            this.btnregistration.TabIndex = 5;
            this.btnregistration.Text = "Register";
            this.btnregistration.UseVisualStyleBackColor = true;
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnregistration);
            this.Controls.Add(this.imgcal);
            this.Controls.Add(this.txtbirthdate);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblBirthDate);
            this.Controls.Add(this.lblName);
            this.Name = "RegistrationForm";
            this.Text = "RegistrationForm";
            ((System.ComponentModel.ISupportInitialize)(this.imgcal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblBirthDate;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.PictureBox imgcal;
        private System.Windows.Forms.Button btnregistration;
        public System.Windows.Forms.TextBox txtbirthdate;
    }
}