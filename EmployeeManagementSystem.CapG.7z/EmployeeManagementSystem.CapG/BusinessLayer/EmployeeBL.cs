﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using Exception;
using DataAccessLayer;
using System.Data;

namespace BusinessLayer
{
    public class EmployeeBL
    {
        public int AddEmployee(Employee eobj)
        {
            try
            {
                EmployeeDAL ed = new EmployeeDAL();
                return ed.AddEmployee(eobj);
            }
            catch (EmployeeException)
            {
                throw;
            }
        }
        public bool EditEmployee(Employee eobj)
        {
            try
            {
                EmployeeDAL ed = new EmployeeDAL();
                return ed.EditEmployee(eobj);
            }
            catch (EmployeeException)
            {
                throw;
            }
        }
        public bool DeleteEmployee(int employeeId)
        {
            try
            {
                EmployeeDAL ed = new EmployeeDAL();
                return ed.DeleteEmployee(employeeId);
            }
            catch (EmployeeException)
            {
                throw;
            }
        }
        public Employee Search(int employeeId)
        {
            try
            {
                EmployeeDAL ed = new EmployeeDAL();
                return ed.Search(employeeId);
            }
            catch (EmployeeException)
            {
                throw;
            }
        }
        public DataTable Display()
        {
            try
            {
                EmployeeDAL ed = new EmployeeDAL();
                return ed.Display();
            }
            catch (EmployeeException)
            {
                throw;
            }
        }
    }
}