﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using Entity;
using Exceptions;
using System.Data;


namespace EmployeeBL
{
    public class EmployeeBL
    {
        public int AddEmployee(Employee eobj)
        {
            try
            {
                Employee pd = new EmployeeDAL();
                return pd.AddProduct(pobj);
            }
            catch (ProductException)
            {
                throw;
            }
        }
    }
}
