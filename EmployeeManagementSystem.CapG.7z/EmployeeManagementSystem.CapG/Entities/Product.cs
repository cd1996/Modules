﻿namespace Entities
{
    public class Employee
    {
    }
}