﻿namespace Entity
{
    public class Employee
    {
        public string EmployeeName { get; set; }
        public string EmployeeEmail { get; set; }
        public long Number { get; set; }
        public string Designation { get; set; }
        public int EmployeeID { get; set; }
    }
    public enum Designation { HR, Analyst, GE, VP, P };
}