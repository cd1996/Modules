﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using Exception;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace DataAccessLayer
{

    public class EmployeeDAL
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pboj"></param>
        /// <returns></returns>
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static EmployeeDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public EmployeeDAL()
        {
            con = new SqlConnection(conStr);

        }
        public int AddEmployee(Employee eboj)
        {
            int eid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "Sarthak.AddEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@EID", SqlDbType.Int);
                cmd.Parameters["@EID"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@EName", eboj.EmployeeName);
                cmd.Parameters.AddWithValue("@EEmail", eboj.EmployeeEmail);
                cmd.Parameters.AddWithValue("@Num", eboj.Number);
                cmd.Parameters.AddWithValue("@Desg", eboj.Designation);


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                eid = int.Parse(cmd.Parameters["@EID"].Value.ToString());
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return eid;
        }
        public bool EditEmployee(Employee eboj)
        {
            bool result = false;
            try
            {
                // con = new SqlConnection();
                //   con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Sarthak.EditEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EName", eboj.EmployeeName);
                cmd.Parameters.AddWithValue("@EEmail", eboj.EmployeeEmail);
                cmd.Parameters.AddWithValue("@Num", eboj.Number);
                cmd.Parameters.AddWithValue("@Desg", eboj.Designation);




                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }
        public bool DeleteEmployee(int employeeId)
        {
            bool result = false;
            try
            {
                //  con = new SqlConnection();
                // con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Sarthak.DeleteEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@EID", employeeId);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
            }
            catch (EmployeeException)
            { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }
        public Employee Search(int employeeId)
        {
              Employee e = null;

            try
            {
                //  con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Sarthak.SearchEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EID", employeeId);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    e = new Employee
                    {
                        EmployeeID = int.Parse(dr["EmployeeID"].ToString()),
                        EmployeeName = dr["EmployeeName"].ToString(),
                        EmployeeEmail = dr["EmployeeEmail"].ToString(),
                        Number = long.Parse(dr["ContactNo"].ToString()),
                       Designation = dr["Designation"].ToString()
                      
                    };
                    dr.Close();
                }
            }
            catch (EmployeeException) {throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return e;
        }
        public DataTable Display()
        {
            DataTable dt = null;

            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Sarthak.GetEmployee";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (EmployeeException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        public DataTable GetCities()
        {
            DataTable dt = null;
            try
            {
                // con = new SqlConnection();
                // con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Sarthak.GetCities";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (SqlException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            catch (SystemException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }

}