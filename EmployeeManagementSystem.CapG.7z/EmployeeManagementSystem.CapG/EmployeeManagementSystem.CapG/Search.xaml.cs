﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entity;
using Exception;
using DataAccessLayer;
using BusinessLayer;
namespace EmployeeManagementSystem.CapG
{
    /// <summary>
    /// Interaction logic for Search.xaml
    /// </summary>
    public partial class Search : Window
    {
        public Search()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeBL pb = new EmployeeBL();
                Employee p = pb.Search(int.Parse(txt5.Text));
                if (p != null)
                {
                    txtname.Text = p.EmployeeName;
                    txtemail.Text = p.EmployeeEmail;
                    txtnumber.Text = p.Number.ToString();
                    txtdesig.Text = p.Designation;
                   
                   // gb1.Visibility = Visibility.Visible;
                }
                else
                {
                    //gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show
                        (string.Format("Product with id {0} does not exists.", txt5.Text),
                        "Product Management System");
                }
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }

        private void Txt5_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
