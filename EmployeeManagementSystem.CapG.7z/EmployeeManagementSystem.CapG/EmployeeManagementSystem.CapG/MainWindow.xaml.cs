﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entity;
using Exception;
using DataAccessLayer;
using BusinessLayer;

namespace EmployeeManagementSystem.CapG
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee ed = new Employee
                {
                    EmployeeName = txt1.Text,
                    EmployeeEmail = txt2.Text,
                    Number = long.Parse(txt3.Text),
                    Designation = cmbdesignation.SelectedValue.ToString()

                 };
                EmployeeBL eb = new EmployeeBL();
                int eid = eb.AddEmployee(ed);
                MessageBox.Show(string.Format("New Product Added.\nProduct Id: {0}", eid),
                    "Product Management System");
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cmbdesignation.ItemsSource = Enum.GetValues(typeof(Designation));
        }
    }
}
