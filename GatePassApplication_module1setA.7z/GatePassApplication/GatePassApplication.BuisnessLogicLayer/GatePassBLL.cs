﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GatePassApplication.Entities;
using GatePassApplication.Exceptions;
using GatePassApplication.DataAccessLayer;


namespace GatePassApplication.BuisnessLogicLayer
{
    public class GatePassBLL
    {
        private static bool ValidateVistor(Visitor visitor)
        {
            StringBuilder sb = new StringBuilder();
            bool validVisitor = true;
            double h;

            if (!(visitor.GatePassID.StartsWith("C" ))  && !(visitor.GatePassID.Length==5))
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Invalid Gate Pass ID");

            }
            if (visitor.VisitorsName == string.Empty)
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "Visitors Name Required");

            }
            if((int)visitor.purposeOfVisit==0 || (int)visitor.purposeOfVisit==1 | (int)visitor.purposeOfVisit==2)
            {
                validVisitor = true;
               //


            }else
            {
                sb.Append(Environment.NewLine + "Purpose should be in interview ,meeting,training");
            }
             h = (int)(visitor.ContactNumber /1000000000);
        

            if (h==8||h==9)

            {
                validVisitor = true;
                
            }
            else
            {
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number & it should be start with 8 or 9");

            }
           
           /* if(visitor.PurposeOfVisit.Equals("interview") || visitor.PurposeOfVisit.Equals("Meeting") || visitor.PurposeOfVisit.Equals("Training") )
            {
                validVisitor = false;
                sb.Append(Environment.NewLine + "your purpose should be of interview, meeting or training");
            }
            */

            if (validVisitor == false)
                throw new GatePassException(sb.ToString());
            return validVisitor;
        }

        public static Visitor SearchVisitorBL(string searchPassID)
        {
            Visitor searchGuest = null;
            try
            {
               GatePassDAL  visitorDAL = new GatePassDAL();
                searchGuest = visitorDAL.SearchGuestDAL(searchPassID);
            }
            catch (GatePassException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchGuest;

        }
        public static bool AddVisitorBL(Visitor visitor)
        {
            bool guestAdded = false;
            try
            {
                if (ValidateVistor(visitor))
                {
                    GatePassDAL guestDAL = new GatePassDAL();
                    guestAdded = guestDAL.AddGuestDAL(visitor);
                }
            }
            catch (GatePassException ex)
            {
                throw new GatePassException(ex.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return guestAdded;
        }


        public static List<Visitor> GetAllVisitor()
        {
            List<Visitor> visitortList = null;
            try
            {
                GatePassDAL visitor = new GatePassDAL();
               visitortList = visitor.DisplayAllguest();
            }
            catch (GatePassException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return visitortList;
        }






    }
    


}
