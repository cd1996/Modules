﻿using GatePassApplication.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using GatePassApplication.Entities;
using GatePassApplication.Exceptions;

namespace GatePassApplication.DataAccessLayer
{
    public class GatePassDAL
    {

        public static List<Visitor> visitorList = new List<Visitor>();

        public bool AddGuestDAL(Visitor newGuest)
        {
            bool visitorAdded = false;
            try
            {
                visitorList.Add(newGuest);
                visitorAdded = true;
            }
            catch (SystemException ex)
            {
                throw new GatePassException(ex.Message);
            }
            return visitorAdded;

        }



        public Visitor SearchGuestDAL(string searchGuestID)
        {
            Visitor searchGuest = null;
            try
            {
                searchGuest = visitorList.Find(newGuest => newGuest.GatePassID.Equals(searchGuestID));
            }
            catch (SystemException ex)
            {
                throw new GatePassException(ex.Message);
            }
            return searchGuest;
        }

        public List<Visitor> DisplayAllguest()
        {
            return visitorList;
        }


    }
}
