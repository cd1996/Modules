﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace dataconnection
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        string _myConnectionString = @"data Source= ndamssql\sqlilearn;user id=sqluser;password=sqluser;initial catalog =training_19sep18_pune;";
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con1 = new SqlConnection())
            {
                int Id;


                string Name;

                int MId;

                con1.ConnectionString = _myConnectionString;
                con1.StateChange += con1_StateChange;
                con1.Open();
                //  SqlCommand sqlcom = new SqlCommand();
                //  sqlcom.CommandText = "insert into employee(employeeid,name,managerid) values(@EID,@name,@MID)";

                //  SqlParameter spEid = sqlcom.Parameters.Add("@EID", SqlDbType.Int);
                //  spEid.Value = (textBox1.Text); 
                //  SqlParameter p1 = sqlcom.Parameters.Add("@name", SqlDbType.VarChar);
                //  p1.Value = textBox4.Text;
                //  SqlParameter p2 = sqlcom.Parameters.Add("@MID", SqlDbType.Int);
                //  p2.Value =  (textBox3.Text);
                // sqlcom.Connection = con1;
                // sqlcom.ExecuteNonQuery();
                // MessageBox.Show("Saved");
                // SqlDataReader sdr = sqlcom.ExecuteReader();
                //sdr.Read();


                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter("select * from employee", con1);

                sda.Fill(dt);

                con1.Close();

            

                foreach (DataRow singleRow in dt.Rows)
                {
                    MessageBox.Show(singleRow["Employeeid"].ToString() + singleRow["name"].ToString() + singleRow["ManagerID"].ToString());

                }
                dg.ItemsSource = dt.DefaultView;

            }
        }

        private void con1_StateChange(object sender, StateChangeEventArgs e)
        {
            if (e.CurrentState == ConnectionState.Open)
            {
                MessageBox.Show("Connection Established");
            }
            else if (e.CurrentState == ConnectionState.Closed)
            {
                MessageBox.Show("Connection Closed");
            }
        }

        private void dg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
